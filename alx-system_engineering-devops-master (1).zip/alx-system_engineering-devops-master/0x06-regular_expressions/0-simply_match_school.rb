#!/usr/bin/env ruby
#regular expression must match School
puts ARGV[0].scan(/School/).join
