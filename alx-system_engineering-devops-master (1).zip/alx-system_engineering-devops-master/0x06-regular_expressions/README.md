0x06. Regular expression
7 Mandatory Tasks
1 Advanced Task
Commit - 'If it makes you happy, why the Hell are you so sad'
