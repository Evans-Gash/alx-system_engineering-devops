0x04. Loops, conditions and parsing
10 Mandatory Tasts
4 Advanced Tasks
Commit - 'Fast AF boy'
