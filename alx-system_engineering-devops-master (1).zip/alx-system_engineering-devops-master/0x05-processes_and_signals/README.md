0x05. Processes and signals
8 Mandatory Tasks
3 Advanced Tasks
Commit - 'Letsgerrit'
